# Beleg-02 Differentialgleichungen

## Aufgabe 1 - Wärmeleitung in einer Schiene
Die Differentialgleichungen zur Beschreibung der Wärmeleitung in festen Körpern haben Sie in der Vorlesung kennengelernt und sollen im Folgenden angewendet werden. Dazu wird eine Schiene untersucht, welche vereinfacht als eindimensionaler halbunendlich ausgedehnter Körper betrachtet werden kann, siehe folgende Abbildung:

![bild](https://me-lrt.de/img/wst-4-03-halbunendlicher-korper-temperaturverlauf-zeit.png "Quelle: https://me-lrt.de/img/wst-4-03-halbunendlicher-korper-temperaturverlauf-zeit.png")

. Die Wärmeleitung kann dabei über das stationäre Gesetz der Wärmeleitung

![\Large](https://latex.codecogs.com/gif.latex?\bg_white{}\dot{q}(x)&space;=&space;\lambda&space;\dfrac{\partial&space;T}{\partial&space;x})

sowie über die Fourier'sche Differentialgleichung 

![\Large](https://latex.codecogs.com/gif.latex?\bg_white{}\dfrac{\partial&space;T}{\partial&space;t}&space;=&space;a&space;\dfrac{\partial^2&space;T}{\partial&space;x^2})

beschrieben werden, wobei &#955; die Wärme- und *a* die Temperaturleitfähigkeit bezeichnen. Die Stoff- und Geometrieparameter lauten wie folgt:

  - Länge der Schiene *L* = 1 m
  - Wärmeleitfähigkeit &#955; = 50 W / m K
  - spezifische Wärmekapazität der Schiene *c* = 507 J / kg K
  - Dichte der Schiene &#961; = 7850 kg / m3
  
![\Large](https://latex.codecogs.com/gif.latex?\bg_white{}a&space;=&space;\dfrac{\lambda}{\rho~c})

Die Zeitschrittweite &#916;*t* kann auf Grund der numerischen Stabilität nicht beliebig gewählt werden. Dabei ist die Fourier-Zahl Fo das Stabilitätskriterium

![\Large](https://latex.codecogs.com/gif.latex?\bg_white{}\textup{Fo}&space;=&space;a&space;\dfrac{\Delta&space;t}{\Delta&space;x})

mit der Zeitschrittweite &#916;*t*, der örtlichen Gitterauflösung &#916;*x* sowie der Temperaturleitfähigkeit *a*. Beachten Sie bei der Wahl einer Zeitschrittweite, das Fo < 1 sein sollte, aber groß genug um die Rechenzeit nicht unnötig zu vergrößern.  

Für den Fall eines Temperatursprungs am linken Rand und einer konstanten Temperatur am gegenüberliegenden Rand kann die Fourier'sche Differentialgleichung analytisch bestimmt werden:

![\Large](https://latex.codecogs.com/gif.latex?\bg_white{}T(x)&space;=&space;T_S&space;&plus;&space;(T_0&space;-&space;T_S)&space;*&space;\text{erf}\left(\dfrac{x}{\sqrt{4&space;a&space;t}}\right))

wobei erf für das Gauß'sche Fehlerintegral steht. Dieses kann mit Hilfe der Funktion [`scipy.special.erf`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.special.erf.html) berechnet werden.

**Aufgaben:**
  1. Diskretisieren Sie die Fourier'sche Differentialgleichung mittels Vorwärtsdifferenz sowohl in Raum und Zeit (beides 1. Ordnung genau).
  2. Erstellen Sie ein eindimensionales Gitter mit 10 Stützstellen und weisen Sie allen Knoten die Anfangstemperatur *T*<sub>0</sub> = 293.15 K zu. 
  3. Zum Zeitpunkt *t* = 0 s springt die Temperatur an der Stelle *x* = 0 m auf *T*<sub>S</sub> = 393.15 K und behält diese bei. Am anderen Ende der Schiene bleibt die Temperatur unverändert auf dem Anfangsniveau *T*(*x = L*) = *T*<sub>0</sub>. Berechnen Sie mit Hilfe der von Ihnen diskretisierten Gleichung die Temperaturverteilung in der Schiene zu den Zeitpunkten *t* = [5 min, 20 min, 60 min].
  5. Vergleichen Sie Ihre numerische Lösung mit der analytischen Lösung. Wie groß ist jeweils der maximale Fehler?
  6. Erhöhen Sie die örtliche Auflösung von 10 Stützstellen auf 20 Stützstellen. Welchen Einfluss hat dies auf den maximalen Fehler?
  7. Ändern Sie die Diskretisierung im Ort von Vorwärtsdifferenz (1. Ordnung) zu zentraler Differenz (2. Ordnung). Wie verändert sich der maximale Fehler mit jeweils 10 und 20 Stützstellen Gitterauflösung?


## Aufgabe 2 - Elektromagnetischer Schwingkreis

Durch bestimmte Kombination von Widerständen, Spulen und Kondensatoren können in der Elektrotechnik Schwingungen erzeugt werden. Eine solche Schaltung bezeichnet man als elektromagnetischen Schwingkreis. Solch ein Schwingkreis besteht im Allgemeinen aus einem Kondensator und einer Spule. Diese Komponenten können Energie in elektrischen bzw. magnetischen Feldern speichern und abgeben (siehe nachfolgende Abbildung). Im idealen Fall, durch Vernachlässigung der ohm'schen Widerstände, bezeichnet man den Schwingkreis als ungedämpft. Der realitätsnähere Fall, unter Berücksichtigung der ohm'schen Widerstände, wird als gedämpfter elektromagnetischer Schwingkreis bezeichnet. 

![bild](https://www.abiweb.de/assets/courses/media/elektromagn-schwing-01-ca.png "Quelle: https://www.abiweb.de/assets/courses/media/elektromagn-schwing-01-ca.png")

Die mathematische Beschreibung solcher Systeme erfolgt über die Differentialgleichung der gedämpften elektromagnetischen Schwingung:

![\Large](https://latex.codecogs.com/gif.latex?\bg_white{}L&space;\cdot&space;\ddot{Q}(t)&space;&plus;&space;R&space;\cdot&space;\dot{Q}(t)&space;&plus;&space;\dfrac{1}{C}&space;\cdot&space;Q(t)&space;=&space;0)

Die physikalischen Parameter des gegebenen Systems lauten wie folgt:

  - ohmscher Widerstand *R* = 700 &#937;
  - induktiver Widerstand (Spule) *L* = 633 H
  - kapazitiver Widerstand (Kondensator) *C* = 40 · 10<sup>-6</sup> H
  - Startwert *Q*(*t* = 0 s) = 1 A s 

Für Differentialgleichung der gedämpften elektrischen Schwingung kann eine exakte analytische Lösung formuliert werden:

![\Large](https://latex.codecogs.com/gif.latex?\bg_white{}Q(t)&space;=&space;e^{-k&space;t}&space;\left(Q(t_0)&space;\cos{(\omega&space;t)}&space;&plus;&space;\dfrac{Q(t_0)~k}{\omega}&space;\sin{(\omega&space;t)}\right&space;))

Die Parameter *k* und &#969; sind wie folgt definiert:

![\Large](https://latex.codecogs.com/gif.latex?\bg_white{}k&space;=&space;\dfrac{R}{2&space;L})

![\Large](https://latex.codecogs.com/gif.latex?\bg_white{}\omega&space;=&space;\sqrt{\dfrac{1}{L&space;C}&space;-&space;k^2})

**Aufgaben:**
  1. Wandeln Sie die Differentialglichung in zwei Differenzengleichung um. Verwenden Sie dazu das Zentraldifferenzen- und das Vorwärtsdifferenzverfahren.
  2. Berechnen Sie mit Hilfe der Vorwärtsdifferenz den nächsten Wert von *Q*(*t*<sub>1</sub>). 
  3. Verwenden Sie anschließend die zentrale Differenz um das System für weitere 10 s realer Zeit zu simulieren.
  4. Vergleichen Sie Ihre Lösung mit der Analytischen. Geben Sie die ungefähre Zeitschrittweite an, ab welcher die maximale Abweichung zwischen analytischer und numerischer Lösung höchstens &#949; = 10<sup>-4</sup> beträgt.  
